import React, { useEffect, useState } from 'react'
import css from './ExchangeIntroForm.module.scss'
import classnames from 'classnames'
import {
  DeviceTypes,
  gasFeeOptions,
  gasFeeOptionsAdaptive, LoadingStates,
  priceSlippageOptions, Themes
} from 'utils/const'
import { useForm } from 'react-hook-form'
import { Collapse } from 'react-collapse/lib/Collapse'
import SettingsBlock from 'components/SettingsBlock/SettingsBlock'
import Button from 'components/Button/Button'
import { useDispatch, useSelector } from 'react-redux'
import { setTheme, toggleModal } from 'store/actions'
import ModalWallet from 'components/Modal/ModalWallet/ModalWallet'
import { getTokens } from 'store/actions/data'
import IconBitcoin from 'assets/icons/IconBitcoin'
import Calculator from 'Pages/Home/Calculator/Calculator'
import useDebounce from 'hooks/useDebounce'
import Preloader from 'components/Preloader/Preloader'
import axiosBone from 'axiosBone'

const ExchangeIntroForm = ({ className, deviceType }) => {
  const [isCollapseOpened, toggleCollapseStatus] = useState(false)
  const dispatch = useDispatch()
  const loadingState = useSelector(state => state.data.loadingState)
  const userWallet = useSelector(state => state.data.userWallet)
  const tokens = useSelector(state => state.data.availableTokens)
    .map(({ symbol, name, address }) => ({
      label: symbol,
      value: address,
      descriptor: name,
      icon: IconBitcoin
    }))

  const { register, control, watch, setValue, handleSubmit, getValues } = useForm()
  const defaultSource = tokens.find(item => item.label === 'USDT')
  const selectedSource = watch('source', defaultSource)
  const valueSource = watch('source-input') || 0
  const debouncedSourceValue = useDebounce(valueSource, 1000)
  const defaultResult = tokens[1]
  const selectedResult = watch('result', defaultResult) || {}
  // const radioFee = watch('radio input gas-fee')
  // const inputFee = watch('manual input gas-fee')

  const handleExchangeClick = data => {
    const dataRequest = {
      addressFrom: userWallet,
      amount: 1,
      from: data.source.label,
      to: data.result.label
    }

    axiosBone.post('/exchange/swap', dataRequest)
      .then(response => {
        const { to, gas, gasPrice, value, data } = response.data

        const dataExchange = [
          {
            from: userWallet,
            to,
            gas: `0x${(+gas).toString(16)}`,
            gasPrice: `0x${(+gasPrice).toString(16)}`,
            value: `0x${(+value).toString(16)}`,
            data
          }
        ]

        console.log(dataExchange)

        window.ethereum
          .request({
            method: `eth_sendTransaction`,
            params: dataExchange
          })
          .then(response => {
            console.log(response)
          })
          .catch(() => {
            // dispatch(toggleModal(true, <ModalWarning label='Произошла ошибка при выполнении транзакции' />))
          })
      })
  }

  const handleButtonClick = () => {
    dispatch(toggleModal(true, <ModalWallet />))
  }

  const handleClickToggle = () => {
    const container = Object.assign({}, selectedSource)
    setValue('source', Object.assign({}, selectedResult))
    setValue('result', container)
  }

  useEffect(() => {
    dispatch(getTokens())
  }, [dispatch])

  return (
    <div className={classnames(css.wrapper, className)}>
      <form onSubmit={handleSubmit(handleExchangeClick)}>
        <div className={css.currencies}>
          {loadingState === LoadingStates.TOKENS_LOADING &&
            <Preloader className={css.preloader} />
          }
          {loadingState === LoadingStates.TOKENS_LOADED && tokens && tokens.length > 1 &&
            <Calculator
              register={register}
              control={control}
              handleClickToggle={handleClickToggle}
              supportedTokens={tokens}
              userWallet={userWallet}
              defaultSource={defaultSource}
              selectedSource={selectedSource}
              valueSource={debouncedSourceValue}
              defaultResult={defaultResult}
              selectedResult={selectedResult}
              getValues={getValues}
              setValue={setValue}
            />
          }
        </div>
        <button
          className={css.buttonCollapse}
          onClick={() => {
            toggleCollapseStatus(state => !state)
            dispatch(setTheme(isCollapseOpened ? Themes.DARK : Themes.LIGHT))
          }}
          type='button'
        >
          Customize transaction settings
        </button>
        <Collapse
          isOpened={isCollapseOpened}
          theme={{
            collapse: 'ReactCollapse--collapse',
            content: css.collapseContent
          }}
        >
          <SettingsBlock
            className={css.settings}
            label='GAS Fee'
            hint='Some hint for the gas fee block'
            options={deviceType === DeviceTypes.DESKTOP ? gasFeeOptions : gasFeeOptionsAdaptive}
            register={register}
            namespace='gas-fee'
            setValue={setValue}
          />
          <SettingsBlock
            className={css.settings}
            label='Limit additional price slippage'
            hint='Some hint for the price slippage block'
            options={priceSlippageOptions}
            register={register}
            namespace='price-slippage'
            setValue={setValue}
          />
        </Collapse>
        <Button
          className={css.button}
          label={userWallet ? 'Exchange now' : 'Connect Your Wallet'}
          type={userWallet ? 'submit' : 'button'}
          onClick={userWallet ? undefined : handleButtonClick}
        />
      </form>
    </div>
  )
}

export default ExchangeIntroForm

export {
  setFontSize,
  setDeviceType
} from './elasticAdaptive'

export {
  setLang,
  toggleModal,
  setTheme
} from './ui'
